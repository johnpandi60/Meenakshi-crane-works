# Meenakshi Crane Works website

A responsive bilingual (English/Tamil) starter website for Meenakshi Crane Works, Madurai.

## Included
- Responsive website in HTML/CSS/JavaScript
- English/Tamil toggle
- Call and WhatsApp links for 99948 44862
- Basic LocalBusiness structured data for search engines
- Service, contact and safety sections

## Preview locally
Open `index.html` in a browser. No build step is required.

## Before publishing
1. Confirm the phone number and service details are correct.
2. Add your own real photos of the crew, lifting equipment and completed jobs (with customer permission).
3. Add accurate business hours and the exact service area.
4. Do not publish a street address unless customers can visit that location during stated hours.
5. Confirm all claims about crane ownership, lifting capacity, certifications, insurance and safety procedures before adding them.
6. The structured data uses Madurai as the service locality. Update it if your actual base/service coverage differs.

## Domain idea
Try `meenakshicraneworks.in` first, with `meenakshicraneworks.com` as an alternative. Availability is not checked; search the exact name at a reputable domain registrar before purchase.

## Publishing options
- GitHub Pages: suitable for a simple static website.
- Netlify or another static hosting service: upload the folder or connect a repository.
- A custom domain can be connected after you purchase it.

## Google setup
1. Search Google Maps and Google Search for the exact business name first, to avoid creating a duplicate.
2. If no profile exists, go to https://business.google.com/add and sign in with a Google account controlled by the business owner.
3. Use the real-world business name: `Meenakshi Crane Works`.
4. Choose the closest accurate primary category available; do not stuff keywords into the business name.
5. If you travel to customer sites and customers do not visit your base, select service-area business and hide the street address from public view. Add only areas you actually serve.
6. Use the business phone number and website consistently.
7. Complete whichever verification method Google offers. Google chooses the available methods; do not share verification codes.
8. After the site is live, register it at https://search.google.com/search-console and verify ownership. Submit a sitemap if you add one later.
9. Add real photos, accurate hours and services. Ask customers for honest reviews; do not buy or fabricate reviews.

Google may take time to crawl the website and review/verify a Business Profile. This project does not itself publish a site or create/verify a Google listing.
