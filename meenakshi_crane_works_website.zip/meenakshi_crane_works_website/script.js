const toggle = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
toggle?.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  toggle.setAttribute('aria-expanded', String(isOpen));
});
let tamil = false;
const languageButton = document.getElementById('language-toggle');
languageButton?.addEventListener('click', () => {
  tamil = !tamil;
  document.documentElement.lang = tamil ? 'ta' : 'en';
  document.querySelectorAll('[data-en][data-ta]').forEach(el => {
    el.textContent = tamil ? el.dataset.ta : el.dataset.en;
  });
  languageButton.textContent = tamil ? 'English' : 'தமிழ்';
});
document.getElementById('year').textContent = new Date().getFullYear();
